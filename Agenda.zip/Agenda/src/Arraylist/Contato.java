/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arraylist;

/**
 *
 * @author aluno
 */
public class Contato {
   private String nome;
   private String email;
   private String numero;

    public Contato(String nome, String email, String numero) {
        this.nome = nome;
        this.email = email;
        this.numero = numero;
    }
    public Contato() {
        this.nome = null;
        this.email = null;
        this.numero = null;
    }
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }
   
   
}
