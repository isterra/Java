/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arraylist;
import java.util.ArrayList;
import java.util.Iterator;
/**
 *
 * @author aluno
 */
public class Agenda {
    
    private ArrayList<Contato> agenda;
    
    public Agenda(ArrayList<Contato> agenda) {
        this.agenda = agenda;
    }
     public Agenda() {
        this.agenda = new ArrayList<>(); ;
    }
    
    public void adicionaContato(Contato contato){
        int ocorrencia = 0;
        for(int i=0;i<agenda.size();i++){
            if(agenda.get(i) != null){
                if(agenda.get(i).getNumero().equals(contato.getNumero())){
                    ocorrencia =1;
                }
            }
        }
        if(ocorrencia == 0)
        agenda.add(contato);
    }
    public int totalContatos(){
        int i=0;
        Iterator <Contato> iterator = agenda.iterator();
       while(iterator.hasNext()){
           i++;
           iterator.next();
       }
       return i;
      
    }
    public String exibeContato(String nome){
        String retorno="";
        for(int i=0;i<agenda.size();i++){
            if(agenda.get(i).getNome().equals(nome)){
                retorno = "\nNome: "+agenda.get(i).getNome()+ "\nEmail "+
                        agenda.get(i).getEmail() + "\nTelefone "+
                        agenda.get(i).getNumero()+"\n";
                return retorno;
            }
        }
        return "Contato nao encontrado";
    }
    public boolean excluicontato(String nome){
        for(int i=0;i<agenda.size();i++){
            if(agenda.get(i).getNome().equals(nome)){
                agenda.remove(agenda.get(i));
                return true;
            }
        }
        return false;
    }
    
    public void exibeTodosContato(){
        
        for(int i=0;i<agenda.size();i++){
            System.out.println("\n");
            System.out.println((i+1)+"- Contato");
            System.out.println("Nome: "+agenda.get(i).getNome());
            System.out.println("Email "+agenda.get(i).getEmail());
            System.out.println("Telefone "+agenda.get(i).getNumero());
            System.out.println("*************************************");
        }
    }   
}
