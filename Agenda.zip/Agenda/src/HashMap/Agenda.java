/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HashMap;
import java.util.HashMap;
import java.util.Map;
import Arraylist.Contato;
import java.util.Set;

/**
 *
 * @author ISTERRA
 */
public class Agenda {
    Map <String,Contato> agenda ;

    public Agenda() {
        agenda = new HashMap<String,Contato>();        
    }
    
    public void adicionaContato(Contato contato){
        agenda.put(contato.getNome(), contato);
    }
    public int totalContatos(){
        return agenda.size();
    }
    
    public void exibeTodosContato(){
        String retorno="";
        int j=0;
        for(String i:agenda.keySet()){
            System.out.println("*********************************");
            System.out.println(j+1 + " Contato:");
            System.out.println("Nome: "+agenda.get(i).getNome());
            System.out.println("Telefone: "+agenda.get(i).getNumero());
            System.out.println("Email: "+agenda.get(i).getEmail());
            System.out.println("*********************************");
            j++;   
        }
    }
    public String exibeContato(String nome){
        return "\n"+
        "Nome "+agenda.get(nome).getNome()+"\n"+
        "Telefone: "+agenda.get(nome).getNumero()+"\n"+
        "Email: "+agenda.get(nome).getEmail()+"\n";
        
    }
    public boolean excluicontato(String nome){
        if(agenda.get(nome).getNome().equals(nome)==true){
            agenda.remove(nome);
            return true;
        }
        return false;     
    }
    
    
}
