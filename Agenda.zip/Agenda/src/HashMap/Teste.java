/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HashMap;

/**
 *
 * @author ccc
 */
import Arraylist.Contato;
import java.util.Scanner;
public class Teste {
        public static void main(String[] args) {
        Agenda agenda = new Agenda();
        int opcao = 0;
        Scanner scan = new Scanner(System.in);
        do{
            System.out.println("==================================\n Selecione a opção desejada:\n (1) - Insere novo contato na agenda\n (2) - Exibe o número total de contatos da agenda\n (3) - Exibe um contato (pesquisa pelo nome)\n (4) - Exclui um contato (pesquisa pelo nome)\n (5) - Exibe todos os contatos da agenda\n (0) - Sair \n==================================");
            opcao = scan.nextInt();
            scan.nextLine();
            switch (opcao){
                case 1:
                    Contato aux = new Contato();
                    System.out.println("Digite o nome:");
                    aux.setNome(scan.nextLine());
                    System.out.println("Digite o numero:");
                    aux.setNumero(scan.nextLine());
                    System.out.println("Digite o email:");
                    aux.setEmail(scan.nextLine());
                    agenda.adicionaContato(aux);
                    break;
                case 2:
                    System.out.println("Existem "+ agenda.totalContatos() + " contatos na agenda");
                    break;
                case 3:
                    System.out.println("Digite o nome do contato:");
                    System.out.println(agenda.exibeContato(scan.next()));
                      break;
                case 4:
                    boolean verificacao;
                    System.out.println("Digite o nome do contato:");
                    verificacao=agenda.excluicontato(scan.next());
                    if(verificacao == true)
                        System.out.println("Contato excluido.");
                    else 
                        System.out.println("Contato nao encontrado.");
                      break;
                case 5:
                    agenda.exibeTodosContato();
                      break;
                default:
                    break;
              }      
        }while(opcao != 0);

    }
    
}
